print "enter number";
$num=<>;
while($num > 0){
print "enter number";
$num=<>;
}