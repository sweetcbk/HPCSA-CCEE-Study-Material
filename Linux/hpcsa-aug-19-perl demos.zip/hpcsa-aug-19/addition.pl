print "Enter number\n";
$num1=<>;
print "Enter number\n";
$num2=<>;
$sum=$num1+$num2;
print "Addition : $sum";
