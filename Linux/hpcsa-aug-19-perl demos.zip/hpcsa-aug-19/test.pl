print "enter the number";
$num=<>;
chomp($num);
for ($i=1;$i<=10;$i++)
{
    
    print "$num * $i=".($num*$i)."\n";

}
