package mypackage;

our $s=20;
my $v=50;
sub factorial($){
  @arr=@_;
  $num=shift;
  $fact=1;
  for($i=2;$i<=$num;$i++){
     $fact=$fact*$i;
	 
  }
   return $fact;
}

sub addition{
 $a=shift;
 $b=shift;
 $sum=$a+$b;
 return $sum;
}

return 1;


