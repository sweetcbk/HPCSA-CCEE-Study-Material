do{
print "Enter name";
$nm=<>;
print "Wants to enter more(y/n)?\n";
$ans=<>;   
chomp($ans);
}while($ans eq  "y");