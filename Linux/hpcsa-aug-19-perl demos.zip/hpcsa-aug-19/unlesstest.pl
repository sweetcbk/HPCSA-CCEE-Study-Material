$x=3;
unless($x > 4)
{
        print "Number is greater than 4";
}
elsif ($x > 4)
{
        print "Number is less than 4";
}
else
{
        print "Numbers are Equal";
}
