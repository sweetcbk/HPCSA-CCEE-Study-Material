#this is comment
print "Hello world\n";
print "enter name\n";
$name=<>;
print 'Name : $name';
print "Enter address\n";
$addr=<>;
print "address : $addr";
